import os
import cv2
import numpy as np
from tensorflow.keras.models import load_model

model = load_model("model.keras")

def predict_character(image_data):
    image_data = image_data.astype('float32') / 255.0
    image_data = image_data.reshape(1, 64, 64, 1)

    predictions = model.predict(image_data)

    predicted_class = np.argmax(predictions)

    return predicted_class

def predict_from_image(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    image = cv2.resize(image, (64, 64))

    predicted_code = predict_character(image)
    print(f"Predicted Character Code for {image_path}: {predicted_code}")

def predict_from_directory(directory):
    for filename in os.listdir(directory):
        if filename.endswith(".png"):
            image_path = os.path.join(directory, filename)
            predict_from_image(image_path)

directory = "for test/"
predict_from_directory(directory)
