import os
import pandas as pd
import numpy as np
import cv2
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.utils import Sequence
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense


csv_path = "chinese_mnist.csv"
data_dir = "data/"
image_size = (64, 64)
batch_size = 32

data_df = pd.read_csv(csv_path)

class DataGenerator(Sequence):
    def __init__(self, data_df, data_dir, image_size, batch_size, shuffle=True, datagen=None):
        self.data_df = data_df
        self.data_dir = data_dir
        self.image_size = image_size
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.datagen = datagen
        self.on_epoch_end()

    def __len__(self):
        return int(np.ceil(len(self.data_df) / self.batch_size))

    def __getitem__(self, index):
        batch_data = self.data_df.iloc[index * self.batch_size:(index + 1) * self.batch_size]

        images, labels = self.load_data(batch_data)

        if self.datagen:
            images = np.array([self.datagen.random_transform(image) for image in images])

        return images, labels

    def on_epoch_end(self):
        if self.shuffle:
            self.data_df = self.data_df.sample(frac=1).reset_index(drop=True)

    def load_data(self, batch_data):
        images = []
        labels = []

        for index, row in batch_data.iterrows():
            image_filename = f"input_{row['suite_id']}_{row['sample_id']}_{row['code']}.jpg"
            image_path = os.path.join(self.data_dir, image_filename)

            image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

            if image is None:
                continue

            image = cv2.resize(image, self.image_size)
            image = image.astype('float32') / 255.0
            images.append(image)

            label = row["code"] - 1
            labels.append(label)

        images = np.array(images).reshape(-1, *self.image_size, 1)
        labels = np.array(labels)

        return images, labels


# Шум чтобы был
datagen = ImageDataGenerator(
    rotation_range=7,            # Повороты до 10 градусов
    width_shift_range=0.01,        # Горизонтальные сдвиги
    height_shift_range=0.01,       # Вертикальные сдвиги
    shear_range=0.01,              # Сдвиги по углу (сдвиг сдвига)
    zoom_range=0.01,               # Масштабирование
    # fill_mode='nearest',          # Заполнение пустот
    brightness_range=[0.7, 1.3],  # Изменение яркости
    horizontal_flip=True,         # Случайное отражение изображений по горизонтали
    preprocessing_function=lambda x: x + np.random.normal(0, 0.1, x.shape)  # Добавление шума
)

num_classes = data_df["code"].nunique()

model = Sequential()
model.add(Conv2D(32, (3, 3), activation='relu', input_shape=image_size + (1,)))  # Assuming grayscale images
model.add(MaxPooling2D((2, 2)))
# model.add(MaxPooling2D((1, 2)))
model.add(Flatten())
# model.add(Dense(256, activation='relu'))
model.add(Dense(128, activation='relu'))
model.add(Dense(64, activation='relu'))
model.add(Dense(num_classes, activation='softmax'))

from tensorflow.keras.optimizers import Adam

model.compile(loss='sparse_categorical_crossentropy', optimizer=Adam(learning_rate=0.0001), metrics=['accuracy'])

# Если хуево обучается убери datagen
train_datagen = DataGenerator(data_df, data_dir, image_size, batch_size)

# Обучение модели без аугментации на первых нескольких эпохах
model.fit(train_datagen, epochs=7)

# После нескольких эпох можно включить аугментацию
train_datagen_with_augmentation = DataGenerator(data_df, data_dir, image_size, batch_size, datagen=datagen)
model.fit(train_datagen_with_augmentation, epochs=7)

model.save("model.keras")
